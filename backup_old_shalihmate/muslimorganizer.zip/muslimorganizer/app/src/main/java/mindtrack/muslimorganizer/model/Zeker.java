package mindtrack.muslimorganizer.model;

/**
 * Model class for zeker
 */
public class Zeker {
    public String content , fadl ;
    public int numberOfRepeat;

    public Zeker(String content , String fadl , int numberOfRepeat)
    {
        this.content = content ;
        this.fadl = fadl ;
        this.numberOfRepeat = numberOfRepeat ;
    }

}
