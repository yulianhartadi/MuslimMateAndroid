package mindtrack.muslimorganizer.model;

/**
 * Model class for prayer
 */
public class Prayer {
    public String prayerName , time ;

    public Prayer(String prayerName , String time)
    {
        this.prayerName = prayerName ;
        this.time = time ;
    }

}
