package mindtrack.muslimorganizer.model;

import java.util.List;

/**
 * Created by Mohamed mo'men on 4/26/2016.
 */
public class WeatherSave {
    public List<Weather> weathers ;

    public WeatherSave(List<Weather> weathers)
    {
        this.weathers = weathers ;
    }

}
