package mindtrack.muslimorganizer.model;

/**
 * Model class for country
 */
public class Country {
    public String countryName, countryArabicName, countryShortCut;

    public Country(String countryName, String countryArabicName, String countryShortCut) {
        this.countryName = countryName;
        this.countryArabicName = countryArabicName;
        this.countryShortCut = countryShortCut;



    }

}
